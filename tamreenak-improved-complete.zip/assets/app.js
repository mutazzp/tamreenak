'use strict';
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const KEYS = { profile:'tamreenak.profile.v1', plan:'tamreenak.plan.v1', meals:'tamreenak.meals.v1', weights:'tamreenak.weights.v1', logs:'tamreenak.logs.v1', favs:'tamreenak.favs.v1' };
const today = () => { const d=new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
let storageWarningShown=false;
function read(key, fallback){
  try { const v=localStorage.getItem(key); return v===null?fallback:JSON.parse(v); }
  catch { return fallback; }
}
function write(key, value){
  try { localStorage.setItem(key, JSON.stringify(value)); return true; }
  catch {
    if(!storageWarningShown){ storageWarningShown=true; toast('تعذر حفظ البيانات على هذا الجهاز. تحقق من مساحة المتصفح أو إعدادات الخصوصية.'); }
    return false;
  }
}
function toast(msg){ const el=$('#toast'); if(!el)return; el.textContent=msg; el.classList.add('show'); clearTimeout(toast._t); toast._t=setTimeout(()=>el.classList.remove('show'),2600); }
function esc(s){ return String(s??'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function getProfile(){
 const defaults={name:'',sex:'male',age:'',weight:'',height:'',goal:'muscle',place:'home',level:'beginner',activity:'1.55',days:'4',duration:'45',equipment:'mixed',impact:'any',limitations:''};
 const saved=read(KEYS.profile,{});
 return {...defaults,...(saved&&typeof saved==='object'&&!Array.isArray(saved)?saved:{})};
}
function getMeals(){ const v=read(KEYS.meals,[]); return Array.isArray(v)?v:[]; }
function getWeights(){ const v=read(KEYS.weights,[]); return (Array.isArray(v)?v:[]).filter(x=>x&&x.date&&Number.isFinite(Number(x.weight))).sort((a,b)=>a.date.localeCompare(b.date)); }
function getLogs(){ const v=read(KEYS.logs,[]); return Array.isArray(v)?v:[]; }
function getFavs(){ const v=read(KEYS.favs,[]); return Array.isArray(v)?v.filter(x=>Number.isFinite(Number(x))).map(Number):[]; }
function getCoachEndpoint(){
  const configured=window.TAMREENAK_COACH_ENDPOINT;
  if(typeof configured==='string'&&configured.trim()) return configured.trim();
  if(location.hostname==='github.io'||location.hostname.endsWith('.github.io')) return null;
  return '/.netlify/functions/coach';
}
function updateNav(){ const page=document.body.dataset.page; $$('[data-nav]').forEach(a=>a.classList.toggle('active',a.dataset.nav===page)); $$('[data-dock]').forEach(a=>a.classList.toggle('active',a.dataset.dock===page)); }
const installButtonIds=['installBtn','installBtnSettings'];
let deferredInstallPrompt=null;
window.addEventListener('beforeinstallprompt', e=>{ e.preventDefault(); deferredInstallPrompt=e; installButtonIds.forEach(id=>{const b=document.getElementById(id);if(b){b.classList.remove('hidden');b.setAttribute('aria-label','تثبيت تطبيق تمرينك');}}); });
window.addEventListener('appinstalled',()=>{ deferredInstallPrompt=null; toast('تم تثبيت تمرينك بنجاح ✓'); installButtonIds.forEach(id=>document.getElementById(id)?.classList.add('hidden')); });
async function doInstall(){
  if(deferredInstallPrompt){
    try{ deferredInstallPrompt.prompt(); const result=await deferredInstallPrompt.userChoice; if(result.outcome==='accepted')toast('تم قبول تثبيت تمرينك'); }
    catch{ toast('تعذر فتح نافذة التثبيت. استخدم قائمة المتصفح.'); }
    finally{ deferredInstallPrompt=null; }
    return;
  }
  if(/iphone|ipad|ipod/i.test(navigator.userAgent)) toast('افتح مشاركة Safari ثم «إضافة إلى الشاشة الرئيسية»');
  else toast('من قائمة المتصفح اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية»');
}
installButtonIds.forEach(id=>{const b=document.getElementById(id);if(b)b.addEventListener('click',doInstall);});
if('serviceWorker' in navigator && (location.protocol==='https:' || location.hostname==='localhost' || location.hostname==='127.0.0.1')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
const menuBtn=$('#menuBtn'), nav=$('#mainNav');
function closeMenu(){ if(nav)nav.classList.remove('open'); if(menuBtn)menuBtn.setAttribute('aria-expanded','false'); }
if(menuBtn&&nav)menuBtn.addEventListener('click',()=>{const opened=nav.classList.toggle('open');menuBtn.setAttribute('aria-expanded',String(opened));});
if(nav)nav.addEventListener('click',e=>{if(e.target.closest('a'))closeMenu();});
document.addEventListener('click',e=>{if(nav?.classList.contains('open')&&!nav.contains(e.target)&&!menuBtn?.contains(e.target))closeMenu();});

function calorieEstimate(profile=getProfile(), goalOverride=null, proteinFactor=1.6){
  const age=Number(profile.age), weight=Number(profile.weight), height=Number(profile.height), activity=Number(profile.activity||1.2);
  if(!(age>=13&&weight>0&&height>0))return null;
  const sex=profile.sex==='female'?-161:(profile.sex==='male'?5:-78);
  const bmr=10*weight+6.25*height-5*age+sex;
  const tdee=bmr*(Number.isFinite(activity)?activity:1.2);
  const goal=goalOverride||profile.goal;
  // Conservative guidance; no aggressive deficit is suggested for people still growing.
  let target=tdee;
  if(age>=18){ if(goal==='fatloss'||goal==='lose')target=tdee-300; else if(goal==='muscle'||goal==='gain')target=tdee+200; }
  const goalCalories=Math.round(Math.max(0,target)/50)*50;
  return {bmr:Math.round(bmr),tdee:Math.round(tdee),goal:goalCalories,protein:Math.round(weight*proteinFactor),adult:age>=18,bmi:weight/((height/100)**2)};
}
function formatNum(n){ return Number(n).toLocaleString('en-US',{maximumFractionDigits:1}); }
function bmiText(bmi){ if(bmi<18.5)return 'أقل من المعتاد';if(bmi<25)return 'النطاق المعتاد';if(bmi<30)return 'أعلى من المعتاد';return 'مرتفع'; }

// PROFILE
function initProfile(){
 const form=$('#profileForm');if(!form)return;const profile=getProfile();
 const map={name:'#pName',sex:'#pSex',age:'#pAge',weight:'#pWeight',height:'#pHeight',goal:'#pGoal',place:'#pPlace',level:'#pLevel',activity:'#pActivity',days:'#pDays',duration:'#pDuration',equipment:'#pEquipment',impact:'#pImpact',limitations:'#pLimitations'};
 Object.entries(map).forEach(([k,s])=>{const el=$(s);if(el&&profile[k]!==undefined&&profile[k]!==null&&profile[k]!=='')el.value=profile[k];});
 function updateSummary(){const p={...getProfile()};const est=calorieEstimate(p);const bmi=est?.bmi;$('#bmiValue').textContent=bmi?formatNum(bmi):'—';$('#bmiLabel').textContent=bmi?(Number(p.age)<18?'يحتاج مخطط نمو':bmiText(bmi)):'—';$('#ageLabel').textContent=p.age?`${p.age} سنة`:'—';$('#profileSummary').textContent=est?`هدفك: ${goalName(p.goal)}. تتمرن ${p.days||4} أيام أسبوعيًا في ${placeName(p.place)}، ومستواك ${levelName(p.level)}. ${est.adult?`احتياج طاقة تقديري للمحافظة: ${formatNum(est.tdee)} سعرة يوميًا.`:'لأن العمر أقل من 18 سنة، لن يقترح الموقع هدف سعرات لتغيير الوزن؛ الأفضل تخصيص التغذية مع مختص.'}`:'أدخل بياناتك واحفظها لعرض ملخصك.';}
 form.addEventListener('submit',e=>{e.preventDefault();const data={};Object.entries(map).forEach(([k,s])=>data[k]=$(s).value);data.age=Number(data.age);data.weight=Number(data.weight);data.height=Number(data.height);data.days=Number(data.days);write(KEYS.profile,data);updateSummary();toast('تم حفظ ملفك الرياضي ✓');});
 $('#profileReset')?.addEventListener('click',()=>{const p=getProfile();Object.entries(map).forEach(([k,s])=>{if($(s))$(s).value=p[k]??''});updateSummary();toast('تمت استعادة آخر بيانات محفوظة');});
 updateSummary();
}
function goalName(g){return ({muscle:'زيادة العضلات',fatloss:'خفض الدهون',fitness:'لياقة عامة',strength:'زيادة القوة',posture:'تحسين الحركة والوضعية',lose:'خفض تدريجي للوزن',gain:'زيادة تدريجية للوزن',maintain:'المحافظة على الوزن'})[g]||'لياقة عامة';}
function placeName(p){return ({home:'البيت',gym:'النادي',both:'البيت والنادي'})[p]||'البيت';}
function levelName(l){return ({beginner:'مبتدئ',intermediate:'متوسط',advanced:'متقدم'})[l]||'مبتدئ';}

// EXERCISE LIBRARY
let allExercises=[];let visibleExerciseLimit=24;let activeQuick='all';
async function fetchExercises(){ if(allExercises.length)return allExercises; const r=await fetch('assets/exercises.json'); if(!r.ok)throw new Error('تعذر تحميل مكتبة التمارين'); allExercises=await r.json(); return allExercises; }
function isHomeExercise(ex){return /وزن الجسم|لا شيء|حائط|بساط|كرسي|منشفة|رباط|إطار باب|حبل نط|درجة ثابتة|دمبل|حقيبة|كرة|طاولة/.test(ex.equipment)||ex.category==='مرونة ووضعية الظهر';}
function exerciseCard(ex){const favs=getFavs(),logs=getLogs(),done=logs.some(l=>l.exerciseId===ex.id&&l.date===today()),fav=favs.includes(ex.id);return `<article class="exercise-card"><div class="exercise-top"><span class="exercise-id">تمرين #${String(ex.id).padStart(3,'0')}</span><button type="button" class="icon-btn btn-small" data-fav="${ex.id}" aria-label="${fav?'إزالة من':'إضافة إلى'} المفضلة">${fav?'★':'☆'}</button></div><h3>${esc(ex.name)}</h3><div class="exercise-meta"><span class="tag lime-tag">${esc(ex.category)}</span><span class="tag">${esc(ex.level)}</span></div><p>${esc(ex.target)} · ${esc(ex.equipment)}</p><div class="exercise-actions"><button class="btn btn-secondary btn-small" type="button" data-details="${ex.id}">التفاصيل</button><button class="btn ${done?'btn-primary':'btn-ghost'} btn-small" type="button" data-done="${ex.id}">${done?'✓ أُنجز':'أنجزته'}</button></div></article>`;}
async function initExercises(){
 const grid=$('#exerciseGrid');if(!grid)return;
 try{await fetchExercises();}catch(e){grid.innerHTML=`<div class="empty">تعذر تحميل التمارين. افتح الموقع عبر خادم محلي أو استضف الملفات بدل فتح HTML مباشرة.</div>`;return;}
 const category=$('#exerciseCategory');if(category){[...new Set(allExercises.map(e=>e.category))].forEach(cat=>{const o=document.createElement('option');o.value=cat;o.textContent=cat;category.append(o);});}
 const search=$('#exerciseSearch'), level=$('#exerciseLevel'), equipment=$('#exerciseEquipment');
 function render(){const q=(search?.value||'').trim().toLowerCase(),cat=category?.value||'all',lev=level?.value||'all',equip=equipment?.value||'all',favs=getFavs();let list=allExercises.filter(ex=>{const matchText=!q||[ex.name,ex.category,ex.target,ex.equipment].join(' ').toLowerCase().includes(q);return matchText&&(cat==='all'||ex.category===cat)&&(lev==='all'||ex.level===lev)&&(equip==='all'||(equip==='home'?isHomeExercise(ex):!isHomeExercise(ex)))&&(activeQuick!=='favorites'||favs.includes(ex.id))&&(activeQuick!=='home'||isHomeExercise(ex))&&(activeQuick!=='posture'||ex.category==='مرونة ووضعية الظهر');});
  const total=list.length,shown=list.slice(0,visibleExerciseLimit);grid.innerHTML=shown.length?shown.map(exerciseCard).join(''):'<div class="empty">ما لقينا تمرين يطابق خياراتك. جرّب كلمة أو تصنيفًا آخر.</div>';$('#exerciseCount').textContent=`عرض ${shown.length} من ${total} تمرين`;$('#exerciseResultTitle').textContent=activeQuick==='favorites'?'تمارينك المفضلة':activeQuick==='posture'?'تمارين الوضعية':cat==='all'?'كل التمارين':cat;$('#loadMoreExercises')?.classList.toggle('hidden',shown.length>=total);$('#favCount')&&($('#favCount').textContent=favs.length);$('#exerciseDone')&&($('#exerciseDone').textContent=getLogs().filter(l=>l.exerciseId).length);
 }
 [search,category,level,equipment].forEach(el=>el?.addEventListener('input',()=>{visibleExerciseLimit=24;render();}));
 $$('#exerciseQuickFilters [data-quick]').forEach(b=>b.addEventListener('click',()=>{activeQuick=b.dataset.quick;$$('#exerciseQuickFilters .pill').forEach(x=>x.classList.toggle('active',x===b));visibleExerciseLimit=24;render();}));
 $('#clearExerciseFilters')?.addEventListener('click',()=>{if(search)search.value='';if(category)category.value='all';if(level)level.value='all';if(equipment)equipment.value='all';activeQuick='all';$$('#exerciseQuickFilters .pill').forEach(x=>x.classList.toggle('active',x.dataset.quick==='all'));visibleExerciseLimit=24;render();});
 $('#loadMoreExercises')?.addEventListener('click',()=>{visibleExerciseLimit+=24;render();});
 grid.addEventListener('click',e=>{const fav=e.target.closest('[data-fav]');if(fav){const id=Number(fav.dataset.fav),fs=getFavs();write(KEYS.favs,fs.includes(id)?fs.filter(n=>n!==id):[...fs,id]);render();toast(fs.includes(id)?'أزيل من المفضلة':'أضيف إلى المفضلة ★');return;}const details=e.target.closest('[data-details]');if(details){openExercise(Number(details.dataset.details));return;}const done=e.target.closest('[data-done]');if(done){completeExercise(Number(done.dataset.done));render();return;}});
 render();
}
function openExercise(id){const ex=allExercises.find(e=>e.id===id);if(!ex)return;const backdrop=$('#exerciseModal'),content=$('#modalContent');if(!backdrop||!content)return;window._tamreenakLastFocus=document.activeElement;const fav=getFavs().includes(id);content.innerHTML=`<div class="modal-head"><div><span class="eyebrow">تمرين #${String(ex.id).padStart(3,'0')} · ${esc(ex.category)}</span><h2 id="modalTitle">${esc(ex.name)}</h2><p>${esc(ex.target)}</p></div><button class="icon-btn" type="button" id="closeExerciseModal" aria-label="إغلاق">✕</button></div><div class="detail-meta"><span>المستوى: ${esc(ex.level)}</span><span>المعدات: ${esc(ex.equipment)}</span><span>المكان: ${esc(ex.location)}</span><span>${ex.sets} مجموعات</span><span>${esc(ex.reps)}</span><span>راحة ${esc(ex.rest)}</span></div><div class="detail-list"><div class="detail-item"><h4>طريقة الأداء خطوة بخطوة</h4><ol>${ex.steps.map(s=>`<li>${esc(s)}</li>`).join('')}<li>أعد الحركة بتكرار ثابت، وتوقف عندما يتدهور شكل الأداء.</li></ol></div><div class="detail-item"><h4>نقطة التركيز</h4><p>${esc(ex.focus)}</p></div><div class="detail-item"><h4>التنفس</h4><p>${esc(ex.breathing)}</p></div><div class="detail-item"><h4>أخطاء شائعة</h4><p>${esc(ex.mistakes)}</p></div><div class="detail-item"><h4>كيف تعدّل الصعوبة؟</h4><p>${esc(ex.alternatives)}</p></div><div class="detail-item"><h4>السلامة</h4><p>${esc(ex.safety)}</p></div></div><div class="form-actions"><button class="btn btn-primary" id="modalComplete" data-id="${id}">✓ سجّل التمرين</button><button class="btn btn-secondary" id="modalFavorite" data-id="${id}">${fav?'★ إزالة من المفضلة':'☆ أضف للمفضلة'}</button></div>`;
 backdrop.classList.add('open');document.body.classList.add('modal-open');document.body.style.overflow='hidden';$('#closeExerciseModal')?.focus();$('#closeExerciseModal')?.addEventListener('click',closeModal);$('#modalComplete')?.addEventListener('click',()=>{completeExercise(id);closeModal();});$('#modalFavorite')?.addEventListener('click',()=>{const fs=getFavs();write(KEYS.favs,fs.includes(id)?fs.filter(n=>n!==id):[...fs,id]);$('#modalFavorite').textContent=getFavs().includes(id)?'★ إزالة من المفضلة':'☆ أضف للمفضلة';toast('تم تحديث المفضلة');});}
function closeModal(){ $('#exerciseModal')?.classList.remove('open');document.body.classList.remove('modal-open');document.body.style.overflow='';const target=window._tamreenakLastFocus;if(target&&typeof target.focus==='function')target.focus();window._tamreenakLastFocus=null; }
$('#exerciseModal')?.addEventListener('click',e=>{if(e.target.id==='exerciseModal')closeModal();});document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal();closeMenu();}});
function completeExercise(id){const logs=getLogs();logs.unshift({id:Date.now(),date:today(),exerciseId:id,name:allExercises.find(e=>e.id===id)?.name||`تمرين #${id}`,minutes:0,type:'exercise'});write(KEYS.logs,logs.slice(0,400));toast('بطل! تم تسجيل التمرين ✓');}

// PLAN
const splitDays={
2:[['اليوم 1','جسم كامل','قرفصاء، ضغط، سحب، جسر أرداف'],['اليوم 2','جسم كامل','اندفاع، ضغط كتف خفيف، جذع، كارديو'] ],
3:[['اليوم 1','جسم كامل A','قرفصاء، ضغط صدر، سحب ظهر، بلانك'],['اليوم 2','جسم كامل B','جسر أرداف، ضغط كتف، سحب، ديد باغ'],['اليوم 3','لياقة وحركة','كارديو منخفض التأثير وتمارين مرونة'] ],
4:[['اليوم 1','صدر وترايسبس','ضغط صدر، ضغط مائل، تمديد ترايسبس'],['اليوم 2','ظهر وبايسبس','سحب ظهر، سحب علوي، ثني بايسبس'],['اليوم 3','أرجل وجذع','قرفصاء، اندفاع، جسر أرداف، ديد باغ'],['اليوم 4','كتف ولياقة','رفع جانبي، ضغط كتف خفيف، كارديو'] ],
5:[['اليوم 1','صدر','ضغط صدر وتنويعات مناسبة'],['اليوم 2','ظهر','سحب أفقي وعمودي'],['اليوم 3','أرجل','قرفصاء وحركات الورك'],['اليوم 4','كتف وذراع','كتف وبايسبس وترايسبس'],['اليوم 5','جذع وكارديو','جذع ثابت وكارديو متوسط'] ],
6:[['اليوم 1','دفع A','صدر وكتف وترايسبس'],['اليوم 2','سحب A','ظهر وبايسبس'],['اليوم 3','أرجل A','فخذ وأرداف وسمانة'],['اليوم 4','دفع B','تنويعات دفع بوزن متحكم'],['اليوم 5','سحب B','سحب ظهر وذراع'],['اليوم 6','أرجل وجذع','أرجل وجذع وكارديو خفيف'] ]
};
const weekday=['السبت','الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة'];
function makePlan(days,place,goal,level){const work=splitDays[days]||splitDays[4];const schedule={2:[0,3],3:[0,2,4],4:[0,2,4,6],5:[0,1,3,5,6],6:[0,1,2,4,5,6]}[days]||[0,1,3,5];let wi=0;return weekday.map((day,i)=>{const isTraining=schedule.includes(i);let task;if(isTraining){task=work[wi++]||['جلسة إضافية','حركة خفيفة','تمارين حركة وكارديو منخفض التأثير'];}else task=[`راحة ${day}`,'استشفاء','مشي خفيف، نوم جيد، وحركة لطيفة'];if(goal==='posture'&&isTraining)task=[task[0],task[1]+' + حركة',task[2]+'. أضف فقط تمارين وضعية مريحة لا تسبب ألمًا.'];return {day,title:task[1],items:task[2],isTraining,place,goal,level};});}
function initPlan(){const el=$('#weekPlan');if(!el)return;const p=getProfile(),saved=read(KEYS.plan,null);$('#planDays').value=String(saved?.days||p.days||4);$('#planPlace').value=saved?.place||p.place||'home';$('#planGoal').value=saved?.goal||p.goal||'muscle';$('#planLevel').value=saved?.level||p.level||'beginner';$('#planDuration').value=String(saved?.duration||p.duration||45);let curr=saved?.week||makePlan(Number($('#planDays').value),$('#planPlace').value,$('#planGoal').value,$('#planLevel').value);let isSaved=!!saved;
 function render(){el.innerHTML=curr.map(d=>`<div class="day-card ${d.isTraining?'':'off'}"><div class="day">${d.day}</div><strong>${esc(d.title)}</strong><small>${d.isTraining?'● تمرين':'○ راحة'}</small><p class="small" style="margin:9px 0 0;line-height:1.8">${esc(d.items)}</p></div>`).join('');$('#planCaption').textContent=`${$('#planDays').value} أيام تدريب · ${placeName($('#planPlace').value)} · ${goalName($('#planGoal').value)} · ${$('#planDuration').value} دقيقة للجلسة`;$('#planStatus').textContent=isSaved?'محفوظة':'معاينة';}
 $('#generatePlan')?.addEventListener('click',()=>{curr=makePlan(Number($('#planDays').value),$('#planPlace').value,$('#planGoal').value,$('#planLevel').value);isSaved=false;render();$('#planStatus').textContent='معاينة جديدة';toast('تم إنشاء جدول مبدئي');});
 $('#savePlan')?.addEventListener('click',()=>{const obj={days:Number($('#planDays').value),place:$('#planPlace').value,goal:$('#planGoal').value,level:$('#planLevel').value,duration:Number($('#planDuration').value),week:curr,savedAt:new Date().toISOString()};write(KEYS.plan,obj);isSaved=true;savedPlanToast();render();});function savedPlanToast(){toast('تم حفظ خطتك على الجهاز ✓');}
 render();}

// CALORIES & FOOD JOURNAL
const foodSelect=$('#foodName');if(foodSelect)foodSelect.addEventListener('change',()=>{const opt=foodSelect.selectedOptions[0];if(opt?.dataset.cal){$('#foodCal').value=opt.dataset.cal;$('#foodProtein').value=opt.dataset.pro||0;$('#foodCarbs').value=opt.dataset.carb||0;$('#foodFat').value=opt.dataset.fat||0;if($('#foodCustomName'))$('#foodCustomName').classList.add('hidden');}else if(foodSelect.value==='__manual'){ $('#foodCustomName')?.classList.remove('hidden');} });
function initCalories(){const form=$('#foodForm');if(!form)return;const p=getProfile();const currentGoal=()=>$('#calorieGoal')?.value||'maintain';$('#calorieGoal').value=p.goal==='fatloss'?'lose':p.goal==='muscle'?'gain':'maintain';$('#proteinFactor').value='1.6';$('#todayDate').textContent=new Date().toLocaleDateString('ar-JO',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
 function renderTotals(){const meals=getMeals().filter(m=>m.date===today());const sums=meals.reduce((a,m)=>({cal:a.cal+m.cal,pro:a.pro+m.pro,carb:a.carb+m.carb,fat:a.fat+m.fat}),{cal:0,pro:0,carb:0,fat:0});const est=calorieEstimate(p,currentGoal()==='lose'?'lose':currentGoal()==='gain'?'gain':'maintain',Number($('#proteinFactor').value));const target=est?.adult?Math.round((currentGoal()==='lose'?est.tdee-300:currentGoal()==='gain'?est.tdee+200:est.tdee)/50)*50:null;$('#dailyCalories').textContent=target?formatNum(target):'—';$('#bmrCalories').textContent=est?formatNum(est.bmr):'—';$('#proteinTarget').textContent=est&&est.adult?`${formatNum(Number(p.weight)*Number($('#proteinFactor').value))}g`:'—';$('#eatenCalories').textContent=formatNum(sums.cal);$('#eatenProtein').textContent=`${formatNum(sums.pro)}g`;$('#remainingCalories').textContent=target?formatNum(target-sums.cal):'—';$('#calorieProgress').style.width=target?`${Math.min(100,sums.cal/target*100)}%`:'0%';$('#calorieNotice').textContent=est&&!est.adult?'لأن العمر أقل من 18 سنة، لا نعرض هدفًا حراريًا لخفض أو زيادة الوزن. اطلب مساعدة مختص لديه خبرة بالنمو والتغذية.':!est?'أدخل العمر والطول والوزن في ملفك الرياضي حتى نحسب التقدير.':'التقدير تقريبي، وقد لا يناسب حالتك الصحية أو احتياجاتك الفردية.';renderMeals(sums);}
 function renderMeals(sums){const list=$('#foodList'),meals=getMeals().filter(m=>m.date===today());if(!meals.length){list.innerHTML='<div class="empty">لا توجد وجبات مسجلة لليوم.</div>';return;}list.innerHTML=meals.map(m=>`<div class="food-row"><div><strong>${esc(m.name)}</strong><small>${esc(m.servingLabel||`${formatNum(m.grams)}غ`)} · بروتين ${formatNum(m.pro)}غ · كارب ${formatNum(m.carb)}غ · دهون ${formatNum(m.fat)}غ</small></div><div style="display:flex;align-items:center;gap:10px"><span class="cal">${formatNum(m.cal)} سعرة</span><button class="icon-btn btn-small" data-delete-meal="${m.id}" aria-label="حذف">✕</button></div></div>`).join('');}
 form.addEventListener('submit',e=>{e.preventDefault();const opt=foodSelect?.selectedOptions[0];const name=$('#foodCustomName')&&!$('#foodCustomName').classList.contains('hidden')?$('#foodCustomName').value:(foodSelect?.value||'وجبة');const grams=Number($('#foodGrams').value);const per={cal:Number($('#foodCal').value),pro:Number($('#foodProtein').value||0),carb:Number($('#foodCarbs').value||0),fat:Number($('#foodFat').value||0)};if(!name||!Number.isFinite(grams)||grams<=0||!Number.isFinite(per.cal)||per.cal<0){toast('راجع اسم الطعام والكمية والقيم');return;}if(!$('#foodCal').value){toast('أدخل السعرات لكل 100غ');return;}const mult=grams/100,meals=getMeals();meals.unshift({id:Date.now(),date:today(),name,grams,cal:Math.round(per.cal*mult),pro:+(per.pro*mult).toFixed(1),carb:+(per.carb*mult).toFixed(1),fat:+(per.fat*mult).toFixed(1)});write(KEYS.meals,meals.slice(0,1000));form.reset();$('#foodGrams').value=100;$('#foodProtein').value=0;$('#foodCarbs').value=0;$('#foodFat').value=0;$('#foodCal').value='';$('#foodCustomName')?.classList.add('hidden');renderTotals();toast('تمت إضافة الوجبة');});
 $('#manualFood')?.addEventListener('click',()=>{if(foodSelect){foodSelect.value='__manual';let op=foodSelect.querySelector('option[value="__manual"]');if(!op){op=document.createElement('option');op.value='__manual';op.textContent='إدخال يدوي';foodSelect.append(op);}foodSelect.value='__manual';$('#foodCustomName')?.classList.remove('hidden');$('#foodCustomName')?.focus();$('#foodCal').focus();}});
 $('#foodList')?.addEventListener('click',e=>{const b=e.target.closest('[data-delete-meal]');if(!b)return;write(KEYS.meals,getMeals().filter(m=>m.id!==Number(b.dataset.deleteMeal)));renderTotals();toast('تم حذف الوجبة');});
 $('#clearMeals')?.addEventListener('click',()=>{if(confirm('تمسح سجل وجبات اليوم؟')){write(KEYS.meals,getMeals().filter(m=>m.date!==today()));renderTotals();toast('تم مسح سجل اليوم');}});
 let latestAiMeal=null;
 const aiMealForm=$('#aiMealForm');
 aiMealForm?.addEventListener('submit',async e=>{
  e.preventDefault();
  const description=$('#aiMealDescription')?.value.trim();
  if(!description)return;
  const submit=$('#aiMealSubmit'),status=$('#aiMealMessage'),resultBox=$('#aiMealResult');
  submit.disabled=true;submit.textContent='جاري التقدير…';status.textContent='أرسل وصف الوجبة إلى خدمة الذكاء الاصطناعي لتقدير الحصة كاملة.';resultBox.classList.add('hidden');latestAiMeal=null;
  try{
   const endpoint=getCoachEndpoint();if(!endpoint)throw new Error('ميزة الذكاء الاصطناعي تحتاج خادمًا مثل Netlify Functions؛ GitHub Pages يستضيف الملفات الثابتة فقط. يمكنك استخدام بقية الموقع وتقدير السعرات يدويًا.');
   const response=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({task:'meal-estimate',messages:[{role:'user',content:`قدّر القيم الغذائية للحصة الكاملة التالية. أعد الاسم والسعرات والبروتين والكربوهيدرات والدهون بالغرام ودرجة الثقة والافتراضات وفق المخطط المطلوب. وصف الوجبة: ${description}`}],profile:{}})});
   const data=await response.json().catch(()=>({}));
   if(!response.ok)throw new Error(data.error||'تعذّر الاتصال بالخدمة.');
   let estimate;
   try{estimate=JSON.parse(data.answer||'');}catch{const match=String(data.answer||'').match(/\{[\s\S]*\}/);if(match)estimate=JSON.parse(match[0]);}
   if(!estimate||!['calories','protein_g','carbs_g','fat_g'].every(k=>Number.isFinite(Number(estimate[k]))&&Number(estimate[k])>=0))throw new Error('وصل تقدير غير مكتمل. جرّب وصفًا أوضح.');
   latestAiMeal={name:String(estimate.name||'وجبة مقدّرة بالذكاء الاصطناعي').slice(0,160),calories:Number(estimate.calories),protein_g:Number(estimate.protein_g),carbs_g:Number(estimate.carbs_g),fat_g:Number(estimate.fat_g),confidence:estimate.confidence,assumptions:String(estimate.assumptions||'القيم تقريبية وتعتمد على وصف الوجبة.').slice(0,1200)};
   $('#aiMealNumbers').textContent=`${formatNum(latestAiMeal.calories)} سعرة حرارية · بروتين ${formatNum(latestAiMeal.protein_g)}غ · كربوهيدرات ${formatNum(latestAiMeal.carbs_g)}غ · دهون ${formatNum(latestAiMeal.fat_g)}غ`;
   $('#aiMealAssumptions').textContent=`الافتراضات: ${latestAiMeal.assumptions}`;
   const confidenceMap={low:'منخفضة',medium:'متوسطة',high:'مرتفعة'};const confidence=confidenceMap[latestAiMeal.confidence]||'غير محددة';
   $('#aiMealConfidence').textContent=`درجة الثقة: ${confidence} — الأرقام تقديرية وليست قياسًا مخبريًا.`;
   resultBox.classList.remove('hidden');status.textContent='اكتمل التقدير. راجع الافتراضات قبل إضافته إلى سجل وجباتك.';
  }catch(error){status.textContent=`لم نتمكن من تقدير الوجبة. ${error.message||'تحقق من الاتصال وإعداد مفتاح API على الخادم.'}`;}
  finally{submit.disabled=false;submit.textContent='قدّر السعرات ✳';}
 });
 $('#saveAiMeal')?.addEventListener('click',()=>{
  if(!latestAiMeal){toast('قدّر الوجبة أولًا');return;}
  const meals=getMeals();meals.unshift({id:Date.now(),date:today(),name:latestAiMeal.name,grams:0,servingLabel:'حصة تقديرية',cal:Math.round(latestAiMeal.calories),pro:+latestAiMeal.protein_g.toFixed(1),carb:+latestAiMeal.carbs_g.toFixed(1),fat:+latestAiMeal.fat_g.toFixed(1)});write(KEYS.meals,meals.slice(0,1000));latestAiMeal=null;$('#aiMealResult').classList.add('hidden');renderTotals();toast('تمت إضافة التقدير إلى سجل الوجبات');
 });
 $('#recalcCalories')?.addEventListener('click',renderTotals);$('#calorieGoal')?.addEventListener('change',renderTotals);$('#proteinFactor')?.addEventListener('change',renderTotals);renderTotals();}

// PROGRESS
function initProgress(){const wf=$('#weightForm');if(!wf)return;$('#weightDate').value=today();const profile=getProfile();if(profile.weight)$('#weightValue').value=profile.weight;
 function render(){const ws=getWeights(),logs=getLogs();$('#progressWorkouts').textContent=logs.length;$('#progressWeeks').textContent=new Set(logs.map(l=>l.date)).size;$('#progressWeight').textContent=ws.length?`${formatNum(ws[ws.length-1].weight)} كغ`:'—';$('#progressChange').textContent=ws.length>1?`${(ws[ws.length-1].weight-ws[0].weight>0?'+':'')+formatNum(ws[ws.length-1].weight-ws[0].weight)} كغ`:'—';const chart=$('#weightChart');if(ws.length){const slice=ws.slice(-12),min=Math.min(...slice.map(x=>x.weight)),max=Math.max(...slice.map(x=>x.weight)),span=Math.max(1,max-min);chart.innerHTML=slice.map(w=>{const h=22+(w.weight-min)/span*105;return `<div class="chart-col"><b>${formatNum(w.weight)}</b><div class="chart-bar" style="height:${h}px"></div><span>${new Date(w.date+'T12:00:00').toLocaleDateString('ar-JO',{day:'numeric',month:'short'})}</span></div>`;}).join('');}else chart.innerHTML='<div class="empty">سجل وزنك لعرض الرسم.</div>';const list=$('#workoutLogList');if(logs.length){list.innerHTML=logs.slice(0,25).map(l=>`<div class="record-row"><div><strong>${esc(l.name)}</strong><small>${new Date(l.date+'T12:00:00').toLocaleDateString('ar-JO')} · ${l.minutes?`${l.minutes} دقيقة`:'تمرين مسجل'}</small></div><button type="button" class="icon-btn btn-small" data-delete-log="${l.id}">حذف</button></div>`).join('');}else list.innerHTML='<div class="empty">لم تسجل جلسات بعد.</div>';}
 wf.addEventListener('submit',e=>{e.preventDefault();const date=$('#weightDate').value,weight=Number($('#weightValue').value);if(!date||weight<25||weight>350){toast('تأكد من التاريخ والوزن');return;}const ws=getWeights().filter(w=>w.date!==date);ws.push({date,weight});write(KEYS.weights,ws);const p=getProfile();p.weight=weight;write(KEYS.profile,p);render();toast('تم تسجيل الوزن ✓');});
 $('#workoutForm')?.addEventListener('submit',e=>{e.preventDefault();const name=$('#workoutName').value.trim(),minutes=Number($('#workoutMinutes').value);if(!name)return;const logs=getLogs();logs.unshift({id:Date.now(),date:today(),name,minutes,type:'session'});write(KEYS.logs,logs.slice(0,400));$('#workoutName').value='';render();toast('تم تسجيل الجلسة ✓');});
 $('#workoutLogList')?.addEventListener('click',e=>{const b=e.target.closest('[data-delete-log]');if(!b)return;write(KEYS.logs,getLogs().filter(l=>l.id!==Number(b.dataset.deleteLog)));render();toast('تم حذف السجل');});$('#clearWorkoutLogs')?.addEventListener('click',()=>{if(confirm('تمسح كل سجل التمارين؟')){write(KEYS.logs,[]);render();toast('تم مسح السجل');}});render();}

// POSTURE PAGE
async function initPosture(){const grid=$('#postureExerciseGrid');if(!grid)return;try{await fetchExercises();}catch{grid.innerHTML='<div class="empty">تعذر تحميل التمارين.</div>';return;}const list=allExercises.filter(e=>e.category==='مرونة ووضعية الظهر');grid.innerHTML=list.map(exerciseCard).join('');grid.addEventListener('click',e=>{const d=e.target.closest('[data-details]');if(d)openExercise(Number(d.dataset.details));const f=e.target.closest('[data-fav]');if(f){const id=Number(f.dataset.fav),fs=getFavs();write(KEYS.favs,fs.includes(id)?fs.filter(n=>n!==id):[...fs,id]);f.textContent=fs.includes(id)?'☆':'★';toast('تم تحديث المفضلة');}const done=e.target.closest('[data-done]');if(done){completeExercise(Number(done.dataset.done));done.textContent='✓ أُنجز';done.classList.add('btn-primary');}});}

// AI COACH
function initCoach(){const form=$('#chatForm');if(!form)return;const body=$('#chatBody'),input=$('#chatInput');let history=[];function addBubble(role,text){const d=document.createElement('div');d.className=`bubble ${role}`;d.textContent=text;body.appendChild(d);body.scrollTop=body.scrollHeight;return d;}
 const quick=$$('.quick-prompts [data-prompt]');quick.forEach(b=>b.addEventListener('click',()=>{input.value=b.dataset.prompt;form.requestSubmit();}));
 form.addEventListener('submit',async e=>{e.preventDefault();const message=input.value.trim();if(!message)return;input.value='';addBubble('user',message);history.push({role:'user',content:message});const waiting=addBubble('bot','لحظة، براجع سؤالك…');const send=form.querySelector('button[type="submit"]');send.disabled=true;try{const endpoint=getCoachEndpoint();if(!endpoint)throw new Error('GitHub Pages لا يشغّل الخادم المطلوب للذكاء الاصطناعي. انشر نسخة الخادم على Netlify وأضف OPENAI_API_KEY في إعدادات الخادم.');const p=getProfile();const res=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({messages:history.slice(-10),profile:{age:p.age,goal:goalName(p.goal),level:levelName(p.level),place:placeName(p.place)}})});const data=await res.json().catch(()=>({}));if(!res.ok)throw new Error(data.error||'تعذر الاتصال');const answer=data.answer||data.output_text||data.content;if(!answer)throw new Error('وصل رد بدون نص.');waiting.textContent=answer;history.push({role:'assistant',content:answer});$('#coachStatus').textContent='متصل بواجهة OpenAI API';}catch(err){waiting.textContent=`الاتصال الحقيقي بـ ChatGPT غير مفعّل الآن أو فشل الاتصال. ${err.message?`(${err.message})`:''}\n\nلتفعيله: ارفع المشروع إلى Netlify، ثم أضف OPENAI_API_KEY في إعدادات Environment variables بنطاق Functions وأعد النشر. لا تضع المفتاح داخل المتصفح. يمكنك استخدام بقية الموقع دون هذه الخطوة.`;$('#coachStatus').textContent='بانتظار إعداد مفتاح API آمن';}finally{send.disabled=false;body.scrollTop=body.scrollHeight;}});}

// SETTINGS / BACKUP
function initSettings(){if(!$('#exportData'))return;$('#exportData').addEventListener('click',()=>{const all={app:'تمرينك',version:1,exportedAt:new Date().toISOString(),data:Object.fromEntries(Object.values(KEYS).map(k=>[k,read(k,null)]))};const blob=new Blob([JSON.stringify(all,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`tamreenak-backup-${today()}.json`;a.click();URL.revokeObjectURL(url);toast('تم تنزيل النسخة الاحتياطية');});$('#importFile')?.addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;try{const parsed=JSON.parse(await file.text()),data=parsed.data||parsed;if(!data||typeof data!=='object'||Array.isArray(data))throw new Error('invalid');if(!confirm('سيتم استبدال البيانات المحلية بالمحتوى المستورد. متابعة؟'))return;const arrayKeys=[KEYS.meals,KEYS.weights,KEYS.logs,KEYS.favs];for(const k of arrayKeys){if(data[k]!==undefined&&!Array.isArray(data[k]))throw new Error('invalid');}if(data[KEYS.profile]!==undefined&&(typeof data[KEYS.profile]!=='object'||Array.isArray(data[KEYS.profile])))throw new Error('invalid');if(data[KEYS.plan]!==undefined&&data[KEYS.plan]!==null&&typeof data[KEYS.plan]!=='object')throw new Error('invalid');Object.values(KEYS).forEach(k=>{if(Object.prototype.hasOwnProperty.call(data,k))write(k,data[k]);});toast('تم استيراد النسخة الاحتياطية');setTimeout(()=>location.reload(),500);}catch{toast('الملف غير صالح أو ليس نسخة تمرينك');}finally{e.target.value='';}});$('#clearAllData')?.addEventListener('click',()=>{if(confirm('هل أنت متأكد؟ سيتم حذف ملفك وخطتك والوجبات وسجلات التقدم من هذا الجهاز.')){Object.values(KEYS).forEach(k=>localStorage.removeItem(k));toast('تم حذف البيانات');setTimeout(()=>location.reload(),450);}});}

// HOME SUMMARY
function initHome(){if(document.body.dataset.page!=='home')return;const p=getProfile(),est=calorieEstimate(p),logs=getLogs(),weights=getWeights();$('#homeCalories').textContent=est?.adult?formatNum(est.tdee):'—';$('#homeWorkouts').textContent=logs.length;$('#homeWeight').textContent=weights.length?`${formatNum(weights[weights.length-1].weight)} كغ`:p.weight?`${p.weight} كغ`:'—';$('#homeGoal').textContent=goalName(p.goal);}

updateNav();initProfile();initExercises();initPlan();initCalories();initProgress();initPosture();initCoach();initSettings();initHome();
