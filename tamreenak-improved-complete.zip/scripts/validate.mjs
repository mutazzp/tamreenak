import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const expectedPages = ['index.html','profile.html','exercises.html','plan.html','calories.html','posture.html','progress.html','coach.html','settings.html'];
const requiredFiles = [
  ...expectedPages, 'README-AR.md', 'package.json', 'server.mjs', 'sw.js',
  'manifest.webmanifest', '.nojekyll', 'assets/style.css', 'assets/app.js',
  'assets/exercises.json', 'assets/icon.svg', 'assets/icon-192.png', 'assets/icon-512.png',
  'netlify/functions/coach.mjs'
];
const errors = [];
for (const file of requiredFiles) if (!fs.existsSync(path.join(root, file))) errors.push(`ملف ناقص: ${file}`);

const exercisePath = path.join(root, 'assets/exercises.json');
if (fs.existsSync(exercisePath)) {
  try {
    const exercises = JSON.parse(fs.readFileSync(exercisePath, 'utf8'));
    if (!Array.isArray(exercises) || exercises.length !== 200) errors.push('مكتبة التمارين يجب أن تحتوي 200 تمرين بالضبط.');
    else {
      const ids = exercises.map(x => x?.id);
      if (new Set(ids).size !== 200) errors.push('معرّفات التمارين ليست فريدة.');
      const fields = ['name','category','target','equipment','level','sets','reps','rest','steps','focus','breathing','mistakes','alternatives','safety'];
      exercises.forEach((exercise, i) => {
        for (const field of fields) if (exercise[field] === undefined || exercise[field] === null || exercise[field] === '') errors.push(`التمرين ${i + 1}: الحقل ${field} ناقص.`);
        if (!Array.isArray(exercise.steps) || exercise.steps.length === 0) errors.push(`التمرين ${i + 1}: خطوات الأداء غير موجودة.`);
      });
    }
  } catch { errors.push('تعذر قراءة assets/exercises.json كملف JSON صالح.'); }
}

for (const page of expectedPages) {
  const pagePath = path.join(root, page);
  if (!fs.existsSync(pagePath)) continue;
  const html = fs.readFileSync(pagePath, 'utf8');
  if (!/<html[^>]*lang="ar"[^>]*dir="rtl"/i.test(html)) errors.push(`${page}: يجب ضبط اللغة العربية واتجاه RTL.`);
  if (!html.includes('assets/app.js')) errors.push(`${page}: ملف JavaScript الرئيسي غير مربوط.`);
  if (!html.includes('assets/style.css')) errors.push(`${page}: ملف التنسيق الرئيسي غير مربوط.`);
  const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
  const duplicateIds = [...new Set(ids.filter((id, i) => ids.indexOf(id) !== i))];
  if (duplicateIds.length) errors.push(`${page}: معرفات HTML مكررة: ${duplicateIds.join(', ')}`);
  for (const [, target] of html.matchAll(/(?:href|src)="([^"#]+)"/g)) {
    if (/^(?:https?:|mailto:|tel:|data:|javascript:)/i.test(target)) continue;
    const clean = target.split('?')[0];
    if (clean && (clean.endsWith('.html') || clean.startsWith('assets/') || ['manifest.webmanifest','sw.js'].includes(clean))) {
      if (!fs.existsSync(path.join(root, clean))) errors.push(`${page}: مرجع محلي غير موجود: ${clean}`);
    }
  }
}

const appJs = fs.existsSync(path.join(root, 'assets/app.js')) ? fs.readFileSync(path.join(root, 'assets/app.js'), 'utf8') : '';
if (/sk-[A-Za-z0-9_-]{20,}/.test(appJs)) errors.push('احتمال وجود مفتاح API في JavaScript الخاص بالمتصفح؛ أزله فورًا.');
if (errors.length) {
  console.error('فشل فحص تمرينك:');
  for (const error of errors) console.error(`- ${error}`);
  process.exitCode = 1;
} else {
  console.log(`نجح فحص تمرينك: ${expectedPages.length} صفحات، 200 تمرين فريد ومفصّل، والملفات المحلية الأساسية موجودة.`);
}
