const CACHE_NAME='tamreenak-cache-v1';
const CORE=[
 './','./index.html','./profile.html','./exercises.html','./plan.html','./calories.html','./posture.html','./progress.html','./coach.html','./settings.html',
 './manifest.webmanifest','./assets/style.css','./assets/app.js','./assets/exercises.json','./assets/icon.svg','./assets/icon-192.png','./assets/icon-512.png'
];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE_NAME).then(cache=>cache.addAll(CORE)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',event=>{
 const req=event.request;const url=new URL(req.url);
 if(req.method!=='GET'||url.origin!==self.location.origin||url.pathname.includes('/.netlify/functions/')||url.pathname.startsWith('/api/'))return;
 if(req.mode==='navigate'){
  event.respondWith(fetch(req).then(res=>{const copy=res.clone();caches.open(CACHE_NAME).then(c=>c.put(req,copy));return res;}).catch(async()=>{
   const cached=await caches.match(req);if(cached)return cached;
   const byPath=await caches.match('./'+url.pathname.split('/').pop());return byPath||caches.match('./index.html');
  }));return;
 }
 event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{if(res.ok){const copy=res.clone();caches.open(CACHE_NAME).then(c=>c.put(req,copy));}return res;}).catch(()=>cached)));
});
