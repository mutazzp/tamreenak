const rateBuckets = new Map();
const SYSTEM = `أنت مدرب تمرينك، مساعد عربي واضح ومشجع للتدريب العام والتغذية الرياضية. أجب بالعربية الفصحى السهلة أو العربية القريبة من المستخدم، بخطوات منظمة قابلة للتطبيق. لا تدّع أنك طبيب أو أخصائي تغذية مرخّص، ولا تشخّص تقوس العمود الفقري أو الإصابات. إذا كان المستخدم يذكر ألمًا شديدًا أو متزايدًا، خدرًا أو ضعفًا عصبيًا، ألم صدر، إغماء، أو فقد السيطرة على البول/البراز، وجّهه إلى تقييم طبي عاجل مناسب. في أسئلة التقوس، وضّح أن السبب والنوع يحددان العلاج وأن التمارين العامة لا تضمن تصحيح التشوه. لا توصف حميات شديدة أو عجز سعرات لفرد دون 18 عامًا؛ انصحه بالتعامل مع مختص لديه خبرة بالنمو. لا تضمن نتائج أو سرعة تحول الجسم. شجّع على التقنية الصحيحة والتدرج والراحة. لا تطلب بيانات شخصية غير ضرورية.`;
export default async (req) => {
  if (req.method !== 'POST') return new Response(JSON.stringify({ error: 'استخدم POST لهذا الطلب.' }), { status: 405, headers: { 'content-type': 'application/json; charset=utf-8', 'allow': 'POST' } });
  const size = Number(req.headers.get('content-length') || 0);
  if (size > 24000) return Response.json({ error: 'حجم الطلب كبير جدًا.' }, { status: 413 });
  const ip = req.headers.get('x-nf-client-connection-ip') || req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
  const now = Date.now();
  const bucket = rateBuckets.get(ip) || { start: now, count: 0 };
  if (now - bucket.start > 60_000) { bucket.start = now; bucket.count = 0; }
  bucket.count += 1; rateBuckets.set(ip, bucket);
  if (bucket.count > 10) return Response.json({ error: 'تم الوصول إلى حد الطلبات المؤقت؛ جرّب بعد دقيقة.' }, { status: 429 });
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return Response.json({ error: 'مفتاح OPENAI_API_KEY غير مضبوط على الخادم.' }, { status: 503 });
  try {
    const body = await req.json();
    let messages = Array.isArray(body.messages) ? body.messages.slice(-10) : [];
    messages = messages.filter(m => ['user','assistant'].includes(m.role) && typeof m.content === 'string').map(m => ({ role: m.role, content: m.content.slice(0, 1800) }));
    if (!messages.length || !messages.some(m => m.role === 'user')) return Response.json({ error: 'اكتب سؤالك أولًا.' }, { status: 400 });
    const profile = body.profile && typeof body.profile === 'object' ? body.profile : {};
    const isMealEstimate = body.task === 'meal-estimate';
    const context = `
معلومات اختيارية قدمها المستخدم في ملفه: العمر=${String(profile.age ?? 'غير محدد').slice(0,3)}، الهدف=${String(profile.goal ?? 'غير محدد').slice(0,80)}، المستوى=${String(profile.level ?? 'غير محدد').slice(0,50)}، مكان التدريب=${String(profile.place ?? 'غير محدد').slice(0,50)}. تعامل معها كبيانات تقريبية لا كتشخيص.`;
    const mealInstructions = `أنت مقدّر غذائي تقريبي باللغة العربية. قدّر القيم لحصة الوجبة الكاملة كما وصفها المستخدم. لا تدّع دقة ملصق غذائي، واذكر في assumptions أهم الكميات أو طرق التحضير التي افترضتها، ونبّه إذا كان الوصف غير كافٍ أو الزيت/الصوص غير محدد. لا تحوّل الأرقام إلى نصيحة طبية ولا تصف حمية علاجية. إذا لم يمكن التقدير من وصف الوجبة، أعط أفضل تقدير محافظ واذكر عدم اليقين في assumptions. أخرج القيم المطلوبة بالـ kcal والجرام.`;
    const requestBody = { model: process.env.OPENAI_MODEL || 'gpt-4.1-mini', instructions: isMealEstimate ? mealInstructions : SYSTEM + context, input: messages, max_output_tokens: isMealEstimate ? 500 : 850, store: false };
    if (isMealEstimate) requestBody.text = { format: { type: 'json_schema', name: 'meal_estimate', strict: true, schema: { type: 'object', properties: { name: { type: 'string' }, calories: { type: 'number' }, protein_g: { type: 'number' }, carbs_g: { type: 'number' }, fat_g: { type: 'number' }, confidence: { type: 'string', enum: ['low','medium','high'] }, assumptions: { type: 'string' } }, required: ['name','calories','protein_g','carbs_g','fat_g','confidence','assumptions'], additionalProperties: false } } };
    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(requestBody)
    });
    const result = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return Response.json({ error: result.error?.message || 'فشل الاتصال بواجهة OpenAI API.' }, { status: upstream.status >= 400 && upstream.status < 600 ? upstream.status : 502 });
    let answer = result.output_text;
    if (!answer && Array.isArray(result.output)) answer = result.output.flatMap(item => item.content || []).filter(item => item.type === 'output_text').map(item => item.text).join('\n');
    if (!answer) return Response.json({ error: 'وصل رد بدون نص.' }, { status: 502 });
    return Response.json({ answer });
  } catch (error) {
    return Response.json({ error: 'تعذر إكمال الطلب. تأكد من الاتصال وحاول مجددًا.' }, { status: 500 });
  }
};
export const config = { path: '/.netlify/functions/coach' };
